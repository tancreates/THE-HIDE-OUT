const express = require("express");
const bodyParser = require("body-parser");
const ejs = require('ejs')
const https = require("https");
const request = require("request");
const mongoose = require('mongoose');

const app = express();

app.set('view engine', 'ejs');

app.use(express.static("public"));

app.use(bodyParser.urlencoded({extended: true}));

mongoose.connect("mongodb://localhost:27017/reviewDB",{useNewUrlParser:true});

const priceSchema = {
    price:Number
}

const Price = mongoose.model('Price',priceSchema);

const price1=new Price({
    price:20
})

const reviewSchema = {
    name:String,
    message:String
}

const Review = mongoose.model('Review',reviewSchema);

const review1=new Review({
    name:"Pappu",
    message:"Nice Coffee"
})

// review1.save();

const review2=new Review({
    name:"Sona",
    message:"Very Nice Coffee"
})
// review2.save();

const defaultReview = [review1,review2];

app.get("/", function(req,res){
    res.render('home');
})

app.post("/",function(req,res){
    const Name = req.body.name;
    const eMail = req.body.email;

    const Message= req.body.mess;

    const review = new Review({
        name:Name,
        message:Message
    });
    review.save();

    const data = {
        members : [
            {
                email_address : eMail,
                status : "subscribed",
                merge_fields : {
                    FNAME : Name
                }
            }
        ]
    };

    const jsonData = JSON.stringify(data);

    const url = "https://us9.api.mailchimp.com/3.0/lists/f51c7c80e5 ";

    const options = {
        method : "POST",
        auth : "mayank:a4784a070e106e0c49de95d8d3a112ba-us9"
    }

    const request = https.request(url, options, function(response) {

        if(response.statusCode==200){
            res.send("Successfully send");
        }
        else{
            res.send("There was an error while signing up please try again");
        }

        response.on("data",function(data){
            console.log(JSON.parse(data));
        })
    });

    request.write(jsonData);
    request.end();
})

app.post('/review',function(req,res){

    res.redirect('/review');

})

app.get('/review',function(req,res){
    Review.find({},function(err,foundItems){
        if(foundItems.length==0){
            Review.insertMany(defaultReview,function(err){
                if(err){
                    console.log(err);
                  }else{
                    console.log("Successfully saved default items to DB.")
                  }
            });
            res.render('review',{newReviews:foundItems});
        }else{
            res.render('review',{newReviews:foundItems});
        }
    });
})

app.get('/signup',(req,res)=>{
    res.render('sign_up_login')
})

app.post('/signup',(req,res)=>{
    res.redirect('/signup');
})

app.listen(process.env.PORT || 4201, function(){
    console.log("server is running on port 4201");
})


// API key = a4784a070e106e0c49de95d8d3a112ba-us9
// list ID = f51c7c80e5